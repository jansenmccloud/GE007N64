Title: Fishing Rod Support
Author: jansenmccloud
Date: Dec 20, 2025
Category: GE For Fun
Expansion Pak: No
Baserom: NTSC US


This mod enables you to play Goldeneye with the original N64 fishing rod controller (Turicon 64) on original hardware!

The ingame control style "1.3 Kissy" gets replaced by "1.3 Fishy" that lets you use the fishing reel crank to fire your guns - gatling style.

Control style 1.3 Fishy:
- standard fire: A
- gatling gun fire: Fishing Rod Crank forward (D-Pad Up)
- aim: Z
- move/turn: Joystick
- action: B
- next weapon: R, L
- strafe: C Left , C Right
- look: C Up, C Down
- pause: Start

